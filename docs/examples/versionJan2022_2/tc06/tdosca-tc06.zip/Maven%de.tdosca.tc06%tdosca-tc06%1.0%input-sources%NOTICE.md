# Project TDOSCA-TC06-PLAINHW / release <#1.0.0#>

*Copyright (C) 2020 Karsten Reincke / Deutsche Telekom AG <karsten.reincke@telekom.de>*

The classes are licensed as follows:

* Default License: M.I.T
* Deviantly licensed:
  - Greeter.java :- A.p.a.c.h.e-2.0 (see LICENSE.A.p.a.c.h.e-2.0)
  - GreeterTest.java :- A.p.a.c.h.e-2.0 (see LICENSE.A.p.a.c.h.e-2.0)
  - Tipster.java :- B.S.D-3-Clause
  - TipsterTest.java :- B.S.D-3-Clause

Note: In this more or less simple test case we have veiled the license identifiers by dots as not to irritate the scanning tools

Karsten Reincke [kreincke] (karsten.reincke@telekom.de)
Daniel Eder [daniel-eder] (daniel.eder@magenta.at)
Reinhardt Wenzina [wenzi188] (reinhardt@wenzina.com)
